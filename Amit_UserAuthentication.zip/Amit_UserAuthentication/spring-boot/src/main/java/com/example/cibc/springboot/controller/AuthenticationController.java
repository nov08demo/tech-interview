package com.example.cibc.springboot.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import java.awt.*;
import java.awt.image.PixelGrabber;
import java.io.File;

@Controller
public class AuthenticationController {
    @PostMapping("/uploadImage")
    public ResponseEntity<Object> handleFileUpload(@RequestParam("file") MultipartFile file ) {

        String fileName = file.getOriginalFilename();
        File uploadedFiled = new File(fileName);
        processImage(uploadedFiled);
        //TODO required comparison with data output
        return ResponseEntity.ok("Hi User <Person Name> ");
    }

    @PostMapping(value = "/uploadVoice")
    public ResponseEntity<Object> uploadVoiceFile( @RequestParam("file") MultipartFile file)  {
        long duration = 0;// length of audio, seconds
        String fileName = file.getOriginalFilename();
        String suffix = fileName.substring(fileName.lastIndexOf("."));
        StringBuilder sb = new StringBuilder();
        //Voice Comparison
        return ResponseEntity.ok("Welcome to <Details>");
    }

    static void processImage(File uploadedFile) {

        String compareFile = "user.jpg";

        // Load the images
        Image image1 = Toolkit.getDefaultToolkit().getImage(uploadedFile.getName());
        Image image2 = Toolkit.getDefaultToolkit().getImage(compareFile);

        try {

            PixelGrabber grabImage1Pixels = new PixelGrabber(image1, 0, 0, -1,
                    -1, false);
            PixelGrabber grabImage2Pixels = new PixelGrabber(image2, 0, 0, -1,
                    -1, false);

            int[] image1Data = null;

            if (grabImage1Pixels.grabPixels()) {
                int width = grabImage1Pixels.getWidth();
                int height = grabImage1Pixels.getHeight();
                image1Data = new int[width * height];
                image1Data = (int[]) grabImage1Pixels.getPixels();
            }

            int[] image2Data = null;

            if (grabImage2Pixels.grabPixels()) {
                int width = grabImage2Pixels.getWidth();
                int height = grabImage2Pixels.getHeight();
                image2Data = new int[width * height];
                image2Data = (int[]) grabImage2Pixels.getPixels();
            }

            System.out.println("Pixels equal: "
                    + java.util.Arrays.equals(image1Data, image2Data));

        } catch (InterruptedException e1) {
            e1.printStackTrace();
        }
    }
}


